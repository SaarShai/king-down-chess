/* TEMP: repetition diagnostic. */
import { LETTERS, SPENT, colorOf, typeOf } from '../../src/rules/engine';
import { fromFen } from '../../src/rules/setup';
import { resetSearchState, search, qRep, qMoves } from '../../src/ai/search';

const FEN = 'g7/6k1/2q3pp/3o4/1p1p1P2/pQ1O2PP/6K1/2G5 w - - 0 1';
const pos = fromFen(FEN);

function fen(b: number[]): string {
  const rows: string[] = [];
  for (let r = 7; r >= 0; r--) {
    let row = '', empty = 0;
    for (let f = 0; f < 8; f++) {
      const p = b[(r << 3) | f];
      if (!p) { empty++; continue; }
      if (empty) { row += empty; empty = 0; }
      const l = (p & SPENT) ? 'H' : LETTERS[typeOf(p)];
      row += colorOf(p) === 0 ? l : l.toLowerCase();
    }
    if (empty) row += empty;
    rows.push(row);
  }
  return rows.join('/');
}

for (const d of [4]) {
  resetSearchState();
  qRep.hitsPath = 0; qRep.cuts = 0; qRep.minDist = 999; qRep.hmAtHit = 0; qRep.minHm = 999;
  qRep.boardSame = 0; qRep.boardDiff = 0; qRep.diffAt = 0; qRep.diffBoard = []; qRep.diffAnc = [];
  const res = search(pos, { maxDepth: d });
  console.log(d, 'nodes', res.nodes, 'score', res.score);
  console.log(JSON.stringify({ hitsPath: qRep.hitsPath, cuts: qRep.cuts, minDist: qRep.minDist, hmAtHit: qRep.hmAtHit, boardSame: qRep.boardSame, boardDiff: qRep.boardDiff, diffAt: qRep.diffAt }));
  if (qRep.diffAt) {
    console.log('cur', fen(qRep.diffBoard));
    console.log('anc', fen(qRep.diffAnc));
  }
  console.log('moves-into-hit', JSON.stringify(qMoves));
}
