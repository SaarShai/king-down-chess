#!/usr/bin/env -S npx tsx
/**
 * Head-to-head campaign analysis (phase-1 protocol).
 *
 *   tsx tools/campaign-head-to-head.ts --spec sim/specs/<frozen>.json --file sim/out/<run>.jsonl \
 *       --arm white --seed 7
 *
 * `--arm` names the *original spec-side evaluator* (the side that plays board-white before any
 * colour swap). `GameRecord.result` is board-White's score, so every record is re-oriented to the
 * requested arm through `colourSwapped`; a black-arm score is `1 - result` exactly where the two
 * sides were swapped.
 *
 * The estimator is clustered on setup (`configId`): a physical game is one JSONL record (both
 * evaluators took part in it), two opposite colour orientations of the same setup/opening make a
 * pair, and a pair is usable only when both orientations are present *and* ended. Missing or
 * ply-capped games are unknown, never draws: they enter only as conservative allocation bounds
 * (0 or 1), never as 0.5 in the estimate.
 *
 * Identity is verified, not assumed: the file must carry one uniform `src`/`specKey`/`rulesKey`
 * stamp on every record (`identifyArm`), and that stamp must equal the frozen spec's stamp
 * (`stampOf`). An unstamped legacy file or a mismatch is rejected, not analysed.
 */
import { createReadStream, existsSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';
import type { EndReason, GameRecord } from '../src/sim/game';
import type { Job, RunSpec } from '../src/sim/spec';
import { buildJobs, loadSpec, usePairs } from '../src/sim/spec';
import { fromFen, startPosition, toFen } from '../src/rules/setup';
import { stampOf } from '../src/sim/run';
import { mulberry32 } from '../src/sim/rng';
import { identifyArm, type IdentityRecord } from './conditions';

export type Arm = 'white' | 'black';

/** Reasons that end a game with a known result. `plyCap` is *not* an ending: the outcome is unknown. */
const KNOWN_REASONS = new Set<EndReason>([
  'checkmate', 'stalemate', 'draw50', 'drawRepetition', 'drawMaterial',
  'adjudicatedResign', 'adjudicatedDraw',
]);
const DRAW_REASONS = new Set<EndReason>(['stalemate', 'draw50', 'drawRepetition', 'drawMaterial', 'adjudicatedDraw']);
const ADJUDICATED_REASONS = new Set<EndReason>(['adjudicatedResign', 'adjudicatedDraw']);

/** The full start FEN `playGame` would store for this job (exactly its `startGame` + `toFen`). */
export function jobStartFen(job: Job): string {
  if (job.fen) return toFen(fromFen(job.fen));
  if (job.backRankBlack !== job.backRankWhite) {
    return toFen(fromFen(`${job.backRankBlack.toLowerCase()}/pppppppp/8/8/8/8/PPPPPPPP/${job.backRankWhite} w - - 0 1`));
  }
  return toFen(startPosition(job.backRankWhite));
}

/** Which spec-side evaluator plays board-White in this record (before/after the pair's colour swap). */
const specWhiteIsBoardWhite = (rec: GameRecord): boolean => !rec.colourSwapped;

/**
 * `GameRecord.result` is board-White's score. Re-orient it to the requested *spec-side* arm:
 * when the pair was colour-swapped the spec-side White evaluator played board-Black, so its score
 * is the complement.
 */
export function armScore(rec: GameRecord, arm: Arm): number {
  const whiteSpec = arm === 'white';
  const specWhiteScore = whiteSpec ? rec.result : 1 - rec.result;
  return specWhiteIsBoardWhite(rec) ? specWhiteScore : 1 - specWhiteScore;
}

export interface CostStat {
  /** Searched plies (opening-random plies excluded). */
  searchedPlies: number;
  pliesWithNodes: number;
  nodes: number;
  pliesWithMs: number;
  ms: number;
  /** Mean nodes per searched ply that *recorded* nodes; null when none did. */
  meanNodes: number | null;
  /** Mean ms per searched ply that recorded ms; null when none did. */
  meanMs: number | null;
}

const emptyCost = (): CostStat => ({
  searchedPlies: 0, pliesWithNodes: 0, nodes: 0, pliesWithMs: 0, ms: 0, meanNodes: null, meanMs: null,
});

function finalizeCost(cost: CostStat): CostStat {
  return {
    ...cost,
    meanNodes: cost.pliesWithNodes ? cost.nodes / cost.pliesWithNodes : null,
    meanMs: cost.pliesWithMs ? cost.ms / cost.pliesWithMs : null,
  };
}

export interface CostPair { white: CostStat; black: CostStat }

export function costByArm(records: readonly GameRecord[]): CostPair {
  const white = emptyCost();
  const black = emptyCost();
  for (const rec of records) {
    const whiteSpecMovesFirst = specWhiteIsBoardWhite(rec);
    for (let i = 0; i < rec.moves.length; i++) {
      if (i < rec.openingPlies) continue;
      const boardWhiteMover = i % 2 === 0;
      const mover: Arm = (boardWhiteMover === whiteSpecMovesFirst) ? 'white' : 'black';
      const cost = mover === 'white' ? white : black;
      cost.searchedPlies++;
      const ply = rec.moves[i];
      if (typeof ply.nodes === 'number' && Number.isFinite(ply.nodes)) {
        cost.pliesWithNodes++; cost.nodes += ply.nodes;
      }
      if (typeof ply.ms === 'number' && Number.isFinite(ply.ms)) {
        cost.pliesWithMs++; cost.ms += ply.ms;
      }
    }
  }
  return { white: finalizeCost(white), black: finalizeCost(black) };
}

/**
 * Deterministic percentile cluster bootstrap over *setups*. Each resample draws `n` setups with
 * replacement (whole setups stay together), averages their means, and the 2.5/97.5 percentiles of
 * the 10 000 resample means form the interval. Constant input yields `[m, m]`; the same seed always
 * yields the same interval. This is a setup-clustered interval, not a game-level binomial interval.
 */
export function clusterBootstrap(setupMeans: readonly number[], seed: number, resamples = 10000): [number, number] {
  const n = setupMeans.length;
  if (n === 0) throw new Error('clusterBootstrap needs at least one setup mean');
  if (n === 1) return [setupMeans[0], setupMeans[0]];
  const rng = mulberry32(seed >>> 0);
  const means: number[] = new Array(resamples);
  for (let r = 0; r < resamples; r++) {
    let sum = 0;
    for (let k = 0; k < n; k++) sum += setupMeans[Math.floor(rng() * n)];
    means[r] = sum / n;
  }
  means.sort((a, b) => a - b);
  const q = (p: number): number => means[Math.min(resamples - 1, Math.max(0, Math.ceil(p * resamples) - 1))];
  return [q(0.025), q(0.975)];
}

export interface SetupSummary {
  configId: string;
  expectedGames: number;
  observedGames: number;
  expectedPairs: number;
  completeEndedPairs: number;
  /** Requested-arm mean over this setup's complete ended pairs; null when it has none. */
  mean: number | null;
}

export interface Estimate {
  /** `none` (no usable pair), `descriptive-one-setup`, or `cluster-bootstrap`. */
  kind: 'none' | 'descriptive-one-setup' | 'cluster-bootstrap';
  mean: number | null;
  lo: number | null;
  hi: number | null;
  diffFromHalf: number | null;
  setups: number;
  completeEndedPairs: number;
  resamples: number;
}

export interface AllocationBounds {
  /** Equally-weighted-over-setups mean over the full expected allocation, unknown -> 0. */
  lower: number;
  /** Same, unknown -> 1. */
  upper: number;
  expectedGames: number;
  knownGames: number;
  unknownGames: number;
}

export interface Dependence {
  uniqueStartFens: number;
  uniquePairIds: number;
  uniqueOrientationUnits: number;
  /** Pairs whose two orientations replay the identical LAN sequence (a deterministic mirror). */
  mirrorDuplicatePairs: number;
  mirrorPairIds: number[];
}

export interface CampaignAnalysis {
  file: string;
  specId: string;
  arm: Arm;
  paired: boolean;
  bootstrapSeed: number;
  identity: { src: string; specKey: string; rulesKey: string };
  expectedGames: number;
  observedGames: number;
  missingGames: number;
  endReasons: Record<string, number>;
  plyCappedGames: number;
  expectedPairs: number;
  completePairs: number;
  incompletePairs: number;
  absentPairs: number;
  fullyEndedPairs: number;
  eligibleSetups: number;
  totalSetups: number;
  setups: SetupSummary[];
  estimate: Estimate;
  bounds: AllocationBounds | null;
  dependence: Dependence;
  cost: CostPair;
}

const pairKey = (rec: GameRecord): number => rec.pairId;

/**
 * Validate every observed record against the job it claims to be, reject anything unverifiable, and
 * return the setup-clustered analysis. Pure: it takes the already-loaded records.
 */
export function analyzeCampaign(
  spec: RunSpec,
  records: readonly GameRecord[],
  opts: { file: string; arm: Arm; bootstrapSeed: number; resamples?: number },
): CampaignAnalysis {
  const { file, arm } = opts;
  const resamples = opts.resamples ?? 10000;
  const jobs = buildJobs(spec);
  const byId = new Map<number, Job>();
  for (const job of jobs) byId.set(job.gameId, job);

  // Duplicates first: two records for one physical game are two experiments added up as one.
  const seenIds = new Set<number>();
  for (const rec of records) {
    if (seenIds.has(rec.gameId)) throw new Error(`head-to-head: ${file} has duplicate gameId ${rec.gameId}`);
    seenIds.add(rec.gameId);
  }

  // Identity: one uniform stamp, all three fields present, equal to the frozen spec's stamp.
  const identity = identifyArm(file, records as readonly (GameRecord & IdentityRecord)[]);
  const expected = stampOf(spec);
  const missingFields = (['src', 'specKey', 'rulesKey'] as const).filter(f => !identity.values[f]);
  if (missingFields.length) {
    throw new Error(`head-to-head: ${file} cannot be verified against the frozen spec: ${missingFields.join(', ')} missing on at least one record (unstamped legacy file). Campaign analysis needs a full uniform src/specKey/rulesKey stamp.`);
  }
  for (const field of ['src', 'specKey', 'rulesKey'] as const) {
    if (identity.values[field] !== expected[field]) {
      throw new Error(`head-to-head: ${file} ${field} ${identity.values[field]} does not match the frozen spec's ${expected[field]}; refusing to analyse a different experiment.`);
    }
  }

  const expectedOpeningPlies = spec.openingRandomPlies ?? 0;
  const noAdjudication = spec.adjudicate === false;

  // Validate each observed record against its expected job; never drop a bad row.
  for (const rec of records) {
    const job = byId.get(rec.gameId);
    if (!job) throw new Error(`head-to-head: ${file} has gameId ${rec.gameId} outside the frozen spec's ${jobs.length} expected games`);
    if (rec.configId !== job.configId) throw new Error(`head-to-head: gameId ${rec.gameId} configId "${rec.configId}" does not match expected "${job.configId}"`);
    if (rec.pairId !== job.pairId) throw new Error(`head-to-head: gameId ${rec.gameId} pairId ${rec.pairId} does not match expected ${job.pairId}`);
    if (rec.colourSwapped !== job.colourSwapped) throw new Error(`head-to-head: gameId ${rec.gameId} colourSwapped ${rec.colourSwapped} does not match expected ${job.colourSwapped}`);
    if (rec.seed !== job.seed) throw new Error(`head-to-head: gameId ${rec.gameId} seed ${rec.seed} does not match expected ${job.seed}`);
    const wantFen = jobStartFen(job);
    if (rec.startFen !== wantFen) throw new Error(`head-to-head: gameId ${rec.gameId} startFen "${rec.startFen}" does not match the expected full start "${wantFen}"`);
    if (rec.openingPlies !== expectedOpeningPlies) throw new Error(`head-to-head: gameId ${rec.gameId} openingPlies ${rec.openingPlies} does not match the spec's ${expectedOpeningPlies}`);
    if (rec.result !== 0 && rec.result !== 0.5 && rec.result !== 1) throw new Error(`head-to-head: gameId ${rec.gameId} result ${rec.result} is not 0, 0.5 or 1`);
    if (!KNOWN_REASONS.has(rec.reason) && rec.reason !== 'plyCap') throw new Error(`head-to-head: gameId ${rec.gameId} has unknown end reason "${rec.reason}"`);
    if (rec.plies !== rec.moves.length) throw new Error(`head-to-head: gameId ${rec.gameId} plies ${rec.plies} does not match its ${rec.moves.length} recorded plies`);
    if (DRAW_REASONS.has(rec.reason) && rec.result !== 0.5) throw new Error(`head-to-head: gameId ${rec.gameId} reason ${rec.reason} must carry result 0.5, got ${rec.result}`);
    if (rec.reason === 'checkmate' && rec.result === 0.5) throw new Error(`head-to-head: gameId ${rec.gameId} reason checkmate must carry result 0 or 1, got 0.5`);
    if (noAdjudication && ADJUDICATED_REASONS.has(rec.reason)) {
      throw new Error(`head-to-head: gameId ${rec.gameId} ended ${rec.reason} although the frozen spec sets adjudicate:false; the record is inconsistent with the spec`);
    }
  }

  const recById = new Map<number, GameRecord>();
  for (const rec of records) recById.set(rec.gameId, rec);

  // Expected pairs and setups come from the frozen jobs, not from what the file happens to hold.
  const expectedPairs = new Map<number, Job[]>();
  for (const job of jobs) {
    const list = expectedPairs.get(job.pairId) ?? [];
    list.push(job);
    expectedPairs.set(job.pairId, list);
  }
  const expectedSetups = new Map<string, Job[]>();
  for (const job of jobs) {
    const list = expectedSetups.get(job.configId) ?? [];
    list.push(job);
    expectedSetups.set(job.configId, list);
  }

  const endReasons: Record<string, number> = {};
  let plyCappedGames = 0;
  for (const rec of records) {
    endReasons[rec.reason] = (endReasons[rec.reason] ?? 0) + 1;
    if (rec.reason === 'plyCap') plyCappedGames++;
  }

  const pairScoresBySetup = new Map<string, number[]>();
  let completePairs = 0, incompletePairs = 0, absentPairs = 0, fullyEndedPairs = 0;

  for (const [, group] of expectedPairs) {
    const present = group.map(j => recById.get(j.gameId));
    if (present.every(r => r === undefined)) { absentPairs++; continue; }
    if (present.some(r => r === undefined)) { incompletePairs++; continue; }
    completePairs++;
    const recs = present as GameRecord[];
    const allEnded = recs.every(r => r.reason !== 'plyCap');
    if (!allEnded) continue;
    fullyEndedPairs++;
    // A pair's requested-arm score is the mean of its two colour orientations.
    const score = recs.reduce((s, r) => s + armScore(r, arm), 0) / recs.length;
    const setup = group[0].configId;
    const list = pairScoresBySetup.get(setup) ?? [];
    list.push(score);
    pairScoresBySetup.set(setup, list);
  }

  const setups: SetupSummary[] = [];
  const setupMeans: number[] = [];
  for (const [configId, group] of expectedSetups) {
    const scores = pairScoresBySetup.get(configId) ?? [];
    const mean = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null;
    if (mean !== null) setupMeans.push(mean);
    setups.push({
      configId,
      expectedGames: group.length,
      observedGames: group.filter(j => recById.has(j.gameId)).length,
      expectedPairs: new Set(group.map(j => j.pairId)).size,
      completeEndedPairs: scores.length,
      mean,
    });
  }
  setups.sort((a, b) => a.configId.localeCompare(b.configId));

  const eligibleSetups = setupMeans.length;
  const completeEndedPairs = fullyEndedPairs;

  let estimate: Estimate;
  if (completeEndedPairs === 0 || eligibleSetups === 0) {
    estimate = { kind: 'none', mean: null, lo: null, hi: null, diffFromHalf: null, setups: eligibleSetups, completeEndedPairs, resamples };
  } else {
    const mean = setupMeans.reduce((a, b) => a + b, 0) / setupMeans.length;
    if (eligibleSetups === 1) {
      estimate = { kind: 'descriptive-one-setup', mean, lo: null, hi: null, diffFromHalf: mean - 0.5, setups: 1, completeEndedPairs, resamples };
    } else {
      const [lo, hi] = clusterBootstrap(setupMeans, opts.bootstrapSeed, resamples);
      estimate = { kind: 'cluster-bootstrap', mean, lo, hi, diffFromHalf: mean - 0.5, setups: eligibleSetups, completeEndedPairs, resamples };
    }
  }

  // Conservative allocation bounds over *every* expected physical game: unknown -> 0 (lower) / 1
  // (upper), then equally weighted over setups. Not an interval and not a claim.
  let bounds: AllocationBounds | null = null;
  if (jobs.length) {
    let lowerSum = 0, upperSum = 0, known = 0, unknown = 0;
    for (const [, group] of expectedSetups) {
      let lo = 0, hi = 0;
      for (const job of group) {
        const rec = recById.get(job.gameId);
        if (rec && rec.reason !== 'plyCap') {
          const s = armScore(rec, arm);
          lo += s; hi += s; known++;
        } else {
          hi += 1; unknown++;
        }
      }
      lowerSum += lo / group.length;
      upperSum += hi / group.length;
    }
    const n = expectedSetups.size;
    bounds = { lower: lowerSum / n, upper: upperSum / n, expectedGames: jobs.length, knownGames: known, unknownGames: unknown };
  }

  // Dependence: count independent units and flag exact deterministic mirror pairs.
  const startFens = new Set<string>();
  const pairIds = new Set<number>();
  const orientations = new Set<string>();
  for (const rec of records) {
    startFens.add(rec.startFen);
    pairIds.add(rec.pairId);
    orientations.add(`${rec.pairId}:${rec.colourSwapped}`);
  }
  const mirrorPairIds: number[] = [];
  for (const [pid, group] of expectedPairs) {
    if (group.length !== 2) continue;
    const a = recById.get(group[0].gameId);
    const b = recById.get(group[1].gameId);
    if (!a || !b) continue;
    if (a.moves.length === b.moves.length && a.moves.every((m, i) => m.lan === b.moves[i].lan)) mirrorPairIds.push(pid);
  }
  const dependence: Dependence = {
    uniqueStartFens: startFens.size,
    uniquePairIds: pairIds.size,
    uniqueOrientationUnits: orientations.size,
    mirrorDuplicatePairs: mirrorPairIds.length,
    mirrorPairIds,
  };

  return {
    file,
    specId: spec.id,
    arm,
    paired: usePairs(spec),
    bootstrapSeed: opts.bootstrapSeed,
    identity: { src: identity.values.src!, specKey: identity.values.specKey!, rulesKey: identity.values.rulesKey! },
    expectedGames: jobs.length,
    observedGames: records.length,
    missingGames: jobs.length - records.length,
    endReasons,
    plyCappedGames,
    expectedPairs: expectedPairs.size,
    completePairs,
    incompletePairs,
    absentPairs,
    fullyEndedPairs,
    eligibleSetups,
    totalSetups: expectedSetups.size,
    setups,
    estimate,
    bounds,
    dependence,
    cost: costByArm(records),
  };
}

const f = (x: number | null, d = 4): string => (x === null ? 'n/a' : x.toFixed(d));

export function renderReport(a: CampaignAnalysis): string {
  const L: string[] = [];
  L.push(`# Head-to-head campaign analysis`);
  L.push('');
  L.push(`- file: \`${a.file}\``);
  L.push(`- frozen spec: \`${a.specId}\``);
  L.push(`- requested arm (original spec-side evaluator): **${a.arm}**`);
  L.push(`- colour-swapped pairs: ${a.paired ? 'yes' : 'no'}`);
  L.push(`- deterministic bootstrap: ${a.estimate.resamples} resamples, seed ${a.bootstrapSeed}`);
  L.push('');
  L.push(`## Identity (verified)`);
  L.push(`- observed = frozen spec: src \`${a.identity.src}\`, specKey \`${a.identity.specKey}\`, rulesKey \`${a.identity.rulesKey}\``);
  L.push('');
  L.push(`## Physical games`);
  L.push(`- expected ${a.expectedGames}, observed ${a.observedGames}, missing ${a.missingGames}`);
  L.push(`- ply-capped (unknown): ${a.plyCappedGames}`);
  const reasons = Object.entries(a.endReasons).sort((x, y) => x[0].localeCompare(y[0])).map(([k, v]) => `${k} ${v}`);
  L.push(`- end reasons: ${reasons.length ? reasons.join(', ') : 'none'}`);
  L.push('');
  L.push(`## Pairs and setups`);
  L.push(`- expected pairs ${a.expectedPairs}: complete ${a.completePairs}, incomplete ${a.incompletePairs}, absent ${a.absentPairs}, fully ended ${a.fullyEndedPairs}`);
  L.push(`- independent units: start positions ${a.dependence.uniqueStartFens}, setup/opening pairs ${a.dependence.uniquePairIds}, orientation units ${a.dependence.uniqueOrientationUnits}`);
  if (a.dependence.mirrorDuplicatePairs) {
    L.push(`- EXACT DETERMINISTIC MIRROR DUPLICATES: ${a.dependence.mirrorDuplicatePairs} pair(s) (pairIds ${a.dependence.mirrorPairIds.join(', ')}); their two records replay the identical LAN sequence, so the pair carries one game's worth of information.`);
  } else {
    L.push(`- no exact deterministic mirror duplicate pairs detected.`);
  }
  L.push(`- records sharing an identical start/engine assignment are dependent; only the ${a.dependence.uniquePairIds} setup/opening pairs are treated as independent clusters.`);
  L.push('');
  L.push(`## Complete-case estimate (conditional on complete ended pairs)`);
  if (a.estimate.kind === 'none') {
    L.push(`- OMITTED: no usable complete ended pair${a.eligibleSetups < 2 ? ` (eligible setups ${a.eligibleSetups})` : ''}. No interval or claim is made.`);
  } else {
    L.push(`- eligible setups ${a.estimate.setups} of ${a.totalSetups}; complete ended pairs ${a.estimate.completeEndedPairs}`);
    for (const s of a.setups) {
      if (s.mean !== null) L.push(`  - ${s.configId}: ${s.completeEndedPairs}/${s.expectedPairs} pairs, mean ${f(s.mean)}`);
    }
    L.push(`- equally weighted mean over setups: **${f(a.estimate.mean)}**`);
    L.push(`- plain score difference from 0.5: ${a.estimate.diffFromHalf! >= 0 ? '+' : ''}${f(a.estimate.diffFromHalf)}`);
    if (a.estimate.kind === 'cluster-bootstrap') {
      L.push(`- 95% percentile cluster bootstrap over setups: [${f(a.estimate.lo)}, ${f(a.estimate.hi)}] (setup-clustered, not a game-level/binomial interval)`);
    } else {
      L.push(`- one eligible setup: descriptive score only, no inferential interval.`);
    }
    L.push(`- Elo: omitted (a setup-clustered score interval does not justify an Elo precision claim; no infinite-Elo conversion).`);
  }
  L.push('');
  L.push(`## Conservative allocation bounds (not a CI, not a claim)`);
  if (!a.bounds) {
    L.push(`- n/a (no expected games)`);
  } else {
    L.push(`- over all ${a.bounds.expectedGames} expected physical games, missing/capped -> 0 or 1: [${f(a.bounds.lower)}, ${f(a.bounds.upper)}]`);
    L.push(`- known outcomes ${a.bounds.knownGames}, unknown (missing or capped) ${a.bounds.unknownGames}; bounds are equally weighted over setups and are distinct from the complete-case estimate above.`);
  }
  L.push('');
  L.push(`## Recorded search cost (searched plies only; opening-random plies excluded)`);
  for (const side of ['white', 'black'] as const) {
    const c = a.cost[side];
    L.push(`- ${side}: ${c.searchedPlies} searched plies; nodes ${c.nodes} over ${c.pliesWithNodes} plies (mean ${f(c.meanNodes, 1)}/ply); ms ${c.ms.toFixed(1)} over ${c.pliesWithMs} plies (mean ${f(c.meanMs, 2)}/ply)`);
  }
  L.push(`- missing node/ms measurements are omitted from the means, never counted as zero.`);
  L.push('');
  return L.join('\n');
}

export async function loadRecords(file: string): Promise<GameRecord[]> {
  if (!existsSync(file)) throw new Error(`head-to-head: ${file} is missing`);
  const records: GameRecord[] = [];
  const seen = new Set<number>();
  const rl = createInterface({ input: createReadStream(file), crlfDelay: Infinity });
  let lineNo = 0;
  for await (const line of rl) {
    lineNo++;
    if (!line) continue;
    let rec: GameRecord;
    try { rec = JSON.parse(line) as GameRecord; } catch { throw new Error(`head-to-head: ${file} line ${lineNo} is not valid JSON`); }
    if (typeof rec.gameId !== 'number' || !Number.isInteger(rec.gameId)) throw new Error(`head-to-head: ${file} line ${lineNo} has no integer gameId`);
    if (seen.has(rec.gameId)) throw new Error(`head-to-head: ${file} has duplicate gameId ${rec.gameId}`);
    seen.add(rec.gameId);
    records.push(rec);
  }
  return records;
}

export interface CliArgs { spec: string; file: string; arm: Arm; bootstrapSeed: number; resamples: number }

export function parseArgs(argv: readonly string[]): CliArgs {
  const get = (name: string): string | undefined => {
    const eq = `--${name}=`;
    for (let i = 0; i < argv.length; i++) {
      if (argv[i] === `--${name}`) {
        const v = argv[i + 1];
        if (v === undefined || v.startsWith('--')) throw new Error(`head-to-head: --${name} needs a value`);
        return v;
      }
      if (argv[i].startsWith(eq)) return argv[i].slice(eq.length);
    }
    return undefined;
  };
  const spec = get('spec');
  const file = get('file');
  const arm = get('arm');
  const seedText = get('seed');
  if (!spec) throw new Error('head-to-head: --spec PATH is required');
  if (!file) throw new Error('head-to-head: --file JSONL is required');
  if (arm !== 'white' && arm !== 'black') throw new Error('head-to-head: --arm must be white or black');
  if (seedText === undefined) throw new Error('head-to-head: --seed N (deterministic bootstrap seed) is required');
  const bootstrapSeed = Number(seedText);
  if (!Number.isInteger(bootstrapSeed)) throw new Error('head-to-head: --seed must be an integer');
  const resamplesText = get('resamples');
  const resamples = resamplesText === undefined ? 10000 : Number(resamplesText);
  if (!Number.isInteger(resamples) || resamples <= 0) throw new Error('head-to-head: --resamples must be a positive integer');
  return { spec, file, arm, bootstrapSeed, resamples };
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  const spec = loadSpec(['--spec', args.spec]);
  const records = await loadRecords(args.file);
  const analysis = analyzeCampaign(spec, records, { file: args.file, arm: args.arm, bootstrapSeed: args.bootstrapSeed, resamples: args.resamples });
  process.stdout.write(renderReport(analysis) + '\n');
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').toString()) {
  main().catch(e => { console.error(e instanceof Error ? e.message : e); process.exit(2); });
}
